from pico2d import load_image

count = 1
class Grass:
    def __init__(self):
        self.image = load_image('grass.png')

    def draw(self):
        global count 

        if count == 1: 
         self.image.draw(400, 30)
         count += 1
        if count == 2: 
         self.image.draw(400, 60)

    def update(self):
        pass
