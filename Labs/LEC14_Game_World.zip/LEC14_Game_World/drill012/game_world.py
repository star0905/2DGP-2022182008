world = [ [], [] ]  # 객체들의 리스트


def add_object(o, depth):
    world.append((o, depth))
    world.sort(key=lambda x: x[1])  # depth 기준으로 정렬


def remove_object(o):
    for layer in world:
        if o in layer:
            layer.remove(o)
            return

    raise ValueError("Object not found")


def update():
    for o, _ in list(world):
        o.update()


def render():
    for  layer in world:
        for o, _ in layer:
         o.draw()